RUBYSCRIPT2EXE	= 'ruby'
load($0 = ARGV.shift)
