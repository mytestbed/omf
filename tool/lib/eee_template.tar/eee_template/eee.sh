PDIR=$1;shift
APP=$1;shift
DIR=$(pwd)
cd $PDIR
  chmod +x bin/ruby
  export PATH=$(pwd)/bin:$PATH
  export LD_LIBRARY_PATH=$(pwd)/bin:LD_LIBRARY_PATH
  export RUBYLIB=$(pwd)/lib
cd $DIR
exec $PDIR/bin/ruby $PDIR/app/$APP $*
