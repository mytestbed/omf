lib	= File.expand_path(File.dirname(__FILE__)) + '/lib'
$:.clear
$: << lib
